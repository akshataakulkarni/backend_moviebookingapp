package com.moviebooking.auth.exception;

public class JwtGenerationException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public JwtGenerationException(String msg) {
		super(msg);
	}

}
