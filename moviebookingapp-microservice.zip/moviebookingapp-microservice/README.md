"# moviebookingapp-microservice" 
!!!important!!!
need to add role into db first
db.roles.insertMany([
   { name: "ROLE_CUSTOMER" },
   { name: "ROLE_ADMIN" },
])
http://localhost:8081/actuator
